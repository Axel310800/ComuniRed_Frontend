package com.comunired.infrastructure.graphql.resolver;

import com.comunired.application.service.QuejaService;
import com.comunired.infrastructure.graphql.type.EstadisticasQuejas;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

@Controller
public class EstadisticasResolver {

    private final QuejaService quejaService;

    @Autowired
    public EstadisticasResolver(QuejaService quejaService) {
        this.quejaService = quejaService;
    }

    @QueryMapping
    public EstadisticasQuejas estadisticasQuejas() {
        long totalPendientes = quejaService.contarQuejasPorEstado("PENDIENTE");
        long totalEnProgreso = quejaService.contarQuejasPorEstado("EN_PROGRESO");
        long totalResueltos = quejaService.contarQuejasPorEstado("RESUELTO");
        long totalReportes = totalPendientes + totalEnProgreso + totalResueltos;

        return new EstadisticasQuejas(
                (int) totalReportes,
                (int) totalPendientes,
                (int) totalEnProgreso,
                (int) totalResueltos
        );
    }
}
