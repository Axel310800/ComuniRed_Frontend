package com.comunired.infrastructure.graphql.resolver;

import com.comunired.application.dto.CreateQuejaInput;
import com.comunired.application.dto.QuejaDTO;
import com.comunired.application.service.QuejaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class QuejaResolver {

    private final QuejaService quejaService;

    @Autowired
    public QuejaResolver(QuejaService quejaService) {
        this.quejaService = quejaService;
    }

    @QueryMapping
    public List<QuejaDTO> quejas() {
        return quejaService.obtenerTodasLasQuejas();
    }

    @QueryMapping
    public QuejaDTO queja(@Argument Long id) {
        return quejaService.obtenerQuejaPorId(id)
                .orElseThrow(() -> new RuntimeException("Queja no encontrada"));
    }

    @QueryMapping
    public List<QuejaDTO> quejasPorEstado(@Argument String estado) {
        return quejaService.obtenerQuejasPorEstado(estado);
    }

    @MutationMapping
    public QuejaDTO crearQueja(@Argument CreateQuejaInput input) {
        return quejaService.crearQueja(input);
    }

    @MutationMapping
    public QuejaDTO actualizarEstadoQueja(@Argument Long quejaId, @Argument String nuevoEstado) {
        return quejaService.actualizarEstadoQueja(quejaId, nuevoEstado);
    }
}
