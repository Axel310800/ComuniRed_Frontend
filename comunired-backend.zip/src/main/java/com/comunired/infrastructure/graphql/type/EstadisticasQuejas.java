package com.comunired.infrastructure.graphql.type;

public class EstadisticasQuejas {
    private final int totalReportes;
    private final int totalPendientes;
    private final int totalEnProgreso;
    private final int totalResueltos;

    public EstadisticasQuejas(int totalReportes, int totalPendientes, 
                             int totalEnProgreso, int totalResueltos) {
        this.totalReportes = totalReportes;
        this.totalPendientes = totalPendientes;
        this.totalEnProgreso = totalEnProgreso;
        this.totalResueltos = totalResueltos;
    }

    public int getTotalReportes() { return totalReportes; }
    public int getTotalPendientes() { return totalPendientes; }
    public int getTotalEnProgreso() { return totalEnProgreso; }
    public int getTotalResueltos() { return totalResueltos; }
}
