package com.comunired.infrastructure.graphql.resolver;

import com.comunired.application.service.AuthService;
import com.comunired.infrastructure.graphql.input.LoginInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.stereotype.Controller;

@Controller
public class AuthResolver {

    private final AuthService authService;

    @Autowired
    public AuthResolver(AuthService authService) {
        this.authService = authService;
    }

    @MutationMapping
    public AuthService.AuthPayload login(@Argument LoginInput input) {
        return authService.login(input.getEmail(), input.getPassword());
    }
}
