package com.comunired.infrastructure.graphql.resolver;

import com.comunired.application.service.AsignacionService;
import com.comunired.domain.model.Asignacion;
import com.comunired.infrastructure.graphql.input.AsignarQuejaInput;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import java.util.List;

@Controller
public class AsignacionResolver {

    private final AsignacionService asignacionService;

    @Autowired
    public AsignacionResolver(AsignacionService asignacionService) {
        this.asignacionService = asignacionService;
    }

    @QueryMapping
    public List<Asignacion> asignacionesPorSoporte(@Argument Long soporteId) {
        return asignacionService.obtenerAsignacionesPorSoporte(soporteId);
    }

    @MutationMapping
    public Asignacion asignarQueja(@Argument AsignarQuejaInput input) {
        return asignacionService.asignarQuejaASoporte(input.getQuejaId(), input.getSoporteId());
    }

    @MutationMapping
    public Asignacion marcarAsignacionAtendida(@Argument Long asignacionId) {
        return asignacionService.marcarComoAtendida(asignacionId);
    }
}
