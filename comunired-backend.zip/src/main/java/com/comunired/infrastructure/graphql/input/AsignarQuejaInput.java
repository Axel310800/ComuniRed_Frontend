package com.comunired.infrastructure.graphql.input;

public class AsignarQuejaInput {
    private Long quejaId;
    private Long soporteId;

    public AsignarQuejaInput() {}

    public AsignarQuejaInput(Long quejaId, Long soporteId) {
        this.quejaId = quejaId;
        this.soporteId = soporteId;
    }

    public Long getQuejaId() { return quejaId; }
    public void setQuejaId(Long quejaId) { this.quejaId = quejaId; }

    public Long getSoporteId() { return soporteId; }
    public void setSoporteId(Long soporteId) { this.soporteId = soporteId; }
}
