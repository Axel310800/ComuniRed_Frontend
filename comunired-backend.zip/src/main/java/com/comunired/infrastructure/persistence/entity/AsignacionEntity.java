package com.comunired.infrastructure.persistence.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "asignacion")
public class AsignacionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "queja_id", nullable = false)
    private QuejaEntity queja;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "soporte_id", nullable = false)
    private UsuarioEntity soporte;

    @Column(name = "fecha_asignacion", nullable = false)
    private LocalDateTime fechaAsignacion;

    @Column(nullable = false)
    private boolean atendida = false;

    // Constructors
    public AsignacionEntity() {}

    public AsignacionEntity(QuejaEntity queja, UsuarioEntity soporte, 
                           LocalDateTime fechaAsignacion, boolean atendida) {
        this.queja = queja;
        this.soporte = soporte;
        this.fechaAsignacion = fechaAsignacion;
        this.atendida = atendida;
    }

    @PrePersist
    protected void onCreate() {
        if (fechaAsignacion == null) {
            fechaAsignacion = LocalDateTime.now();
        }
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public QuejaEntity getQueja() { return queja; }
    public void setQueja(QuejaEntity queja) { this.queja = queja; }

    public UsuarioEntity getSoporte() { return soporte; }
    public void setSoporte(UsuarioEntity soporte) { this.soporte = soporte; }

    public LocalDateTime getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(LocalDateTime fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }

    public boolean isAtendida() { return atendida; }
    public void setAtendida(boolean atendida) { this.atendida = atendida; }
}
