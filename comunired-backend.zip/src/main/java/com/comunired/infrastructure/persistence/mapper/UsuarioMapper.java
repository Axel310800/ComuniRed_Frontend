package com.comunired.infrastructure.persistence.mapper;

import com.comunired.domain.model.Usuario;
import com.comunired.infrastructure.persistence.entity.UsuarioEntity;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(componentModel = "spring", uses = {RolMapper.class})
public interface UsuarioMapper {
    
    @Mapping(target = "rol", source = "rol")
    Usuario toDomain(UsuarioEntity entity);
    
    @Mapping(target = "rol", source = "rol")
    UsuarioEntity toEntity(Usuario domain);
}
