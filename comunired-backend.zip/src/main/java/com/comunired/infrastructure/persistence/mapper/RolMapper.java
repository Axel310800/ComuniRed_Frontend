package com.comunired.infrastructure.persistence.mapper;

import com.comunired.domain.model.Rol;
import com.comunired.infrastructure.persistence.entity.RolEntity;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface RolMapper {
    
    Rol toDomain(RolEntity entity);
    
    RolEntity toEntity(Rol domain);
}
