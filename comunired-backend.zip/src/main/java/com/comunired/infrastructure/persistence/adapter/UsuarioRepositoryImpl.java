package com.comunired.infrastructure.persistence.adapter;

import com.comunired.domain.model.Usuario;
import com.comunired.domain.repository.UsuarioRepository;
import com.comunired.infrastructure.persistence.entity.UsuarioEntity;
import com.comunired.infrastructure.persistence.mapper.UsuarioMapper;
import com.comunired.infrastructure.persistence.repository.JpaUsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Component
public class UsuarioRepositoryImpl implements UsuarioRepository {

    private final JpaUsuarioRepository jpaUsuarioRepository;
    private final UsuarioMapper usuarioMapper;

    @Autowired
    public UsuarioRepositoryImpl(JpaUsuarioRepository jpaUsuarioRepository, 
                                UsuarioMapper usuarioMapper) {
        this.jpaUsuarioRepository = jpaUsuarioRepository;
        this.usuarioMapper = usuarioMapper;
    }

    @Override
    public Optional<Usuario> findById(Long id) {
        return jpaUsuarioRepository.findById(id)
                .map(usuarioMapper::toDomain);
    }

    @Override
    public Optional<Usuario> findByEmail(String email) {
        return jpaUsuarioRepository.findByEmail(email)
                .map(usuarioMapper::toDomain);
    }

    @Override
    public List<Usuario> findByRolNombre(String rolNombre) {
        return jpaUsuarioRepository.findByRolNombre(rolNombre).stream()
                .map(usuarioMapper::toDomain)
                .collect(Collectors.toList());
    }

    @Override
    public Usuario save(Usuario usuario) {
        UsuarioEntity entity = usuarioMapper.toEntity(usuario);
        UsuarioEntity savedEntity = jpaUsuarioRepository.save(entity);
        return usuarioMapper.toDomain(savedEntity);
    }

    @Override
    public void deleteById(Long id) {
        jpaUsuarioRepository.deleteById(id);
    }

    @Override
    public List<Usuario> findAll() {
        return jpaUsuarioRepository.findAll().stream()
                .map(usuarioMapper::toDomain)
                .collect(Collectors.toList());
    }
}
