package com.comunired.infrastructure.persistence.repository;

import com.comunired.infrastructure.persistence.entity.QuejaEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JpaQuejaRepository extends JpaRepository<QuejaEntity, Long> {
    List<QuejaEntity> findByUsuarioId(Long usuarioId);
    
    @Query("SELECT q FROM QuejaEntity q WHERE q.estado.nombre = :estadoNombre")
    List<QuejaEntity> findByEstadoNombre(@Param("estadoNombre") String estadoNombre);
    
    @Query("SELECT COUNT(q) FROM QuejaEntity q WHERE q.estado.nombre = :estadoNombre")
    long countByEstadoNombre(@Param("estadoNombre") String estadoNombre);
}
