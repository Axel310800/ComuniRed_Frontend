package com.comunired.application.dto;

public class CreateQuejaInput {
    private String descripcion;
    private Long usuarioId;
    private String imagenUrl;

    // Constructors
    public CreateQuejaInput() {}

    public CreateQuejaInput(String descripcion, Long usuarioId, String imagenUrl) {
        this.descripcion = descripcion;
        this.usuarioId = usuarioId;
        this.imagenUrl = imagenUrl;
    }

    // Getters and Setters
    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public Long getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }

    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }
}
