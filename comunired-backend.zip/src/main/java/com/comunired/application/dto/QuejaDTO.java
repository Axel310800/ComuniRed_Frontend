package com.comunired.application.dto;

import java.time.LocalDateTime;

public class QuejaDTO {
    private Long id;
    private String descripcion;
    private LocalDateTime fechaCreacion;
    private Long usuarioId;
    private String usuarioNombre;
    private Long estadoId;
    private String estadoNombre;
    private String imagenUrl;
    private long totalLikes;
    private long totalReacciones;

    // Constructors
    public QuejaDTO() {}

    public QuejaDTO(Long id, String descripcion, LocalDateTime fechaCreacion, 
                   Long usuarioId, String usuarioNombre, Long estadoId, 
                   String estadoNombre, String imagenUrl) {
        this.id = id;
        this.descripcion = descripcion;
        this.fechaCreacion = fechaCreacion;
        this.usuarioId = usuarioId;
        this.usuarioNombre = usuarioNombre;
        this.estadoId = estadoId;
        this.estadoNombre = estadoNombre;
        this.imagenUrl = imagenUrl;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public Long getUsuarioId() { return usuarioId; }
    public void setUsuarioId(Long usuarioId) { this.usuarioId = usuarioId; }

    public String getUsuarioNombre() { return usuarioNombre; }
    public void setUsuarioNombre(String usuarioNombre) { this.usuarioNombre = usuarioNombre; }

    public Long getEstadoId() { return estadoId; }
    public void setEstadoId(Long estadoId) { this.estadoId = estadoId; }

    public String getEstadoNombre() { return estadoNombre; }
    public void setEstadoNombre(String estadoNombre) { this.estadoNombre = estadoNombre; }

    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }

    public long getTotalLikes() { return totalLikes; }
    public void setTotalLikes(long totalLikes) { this.totalLikes = totalLikes; }

    public long getTotalReacciones() { return totalReacciones; }
    public void setTotalReacciones(long totalReacciones) { this.totalReacciones = totalReacciones; }
}
