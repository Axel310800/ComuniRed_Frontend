package com.comunired.application.service;

import com.comunired.application.dto.CreateQuejaInput;
import com.comunired.application.dto.QuejaDTO;
import com.comunired.domain.model.*;
import com.comunired.domain.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class QuejaService {

    private final QuejaRepository quejaRepository;
    private final UsuarioRepository usuarioRepository;
    private final EstadoQuejaRepository estadoQuejaRepository;
    private final ReaccionRepository reaccionRepository;

    @Autowired
    public QuejaService(QuejaRepository quejaRepository, 
                       UsuarioRepository usuarioRepository,
                       EstadoQuejaRepository estadoQuejaRepository,
                       ReaccionRepository reaccionRepository) {
        this.quejaRepository = quejaRepository;
        this.usuarioRepository = usuarioRepository;
        this.estadoQuejaRepository = estadoQuejaRepository;
        this.reaccionRepository = reaccionRepository;
    }

    public List<QuejaDTO> obtenerTodasLasQuejas() {
        return quejaRepository.findAll().stream()
                .map(this::convertirADTO)
                .collect(Collectors.toList());
    }

    public Optional<QuejaDTO> obtenerQuejaPorId(Long id) {
        return quejaRepository.findById(id)
                .map(this::convertirADTO);
    }

    public List<QuejaDTO> obtenerQuejasPorEstado(String estadoNombre) {
        return quejaRepository.findByEstadoNombre(estadoNombre).stream()
                .map(this::convertirADTO)
                .collect(Collectors.toList());
    }

    public QuejaDTO crearQueja(CreateQuejaInput input) {
        Usuario usuario = usuarioRepository.findById(input.getUsuarioId())
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        EstadoQueja estadoPendiente = estadoQuejaRepository.findByNombre("PENDIENTE")
                .orElseThrow(() -> new RuntimeException("Estado PENDIENTE no encontrado"));

        Queja nuevaQueja = new Queja();
        nuevaQueja.setDescripcion(input.getDescripcion());
        nuevaQueja.setFechaCreacion(LocalDateTime.now());
        nuevaQueja.setUsuario(usuario);
        nuevaQueja.setEstado(estadoPendiente);
        nuevaQueja.setImagenUrl(input.getImagenUrl());

        Queja quejaGuardada = quejaRepository.save(nuevaQueja);
        return convertirADTO(quejaGuardada);
    }

    public QuejaDTO actualizarEstadoQueja(Long quejaId, String nuevoEstado) {
        Queja queja = quejaRepository.findById(quejaId)
                .orElseThrow(() -> new RuntimeException("Queja no encontrada"));

        EstadoQueja estado = estadoQuejaRepository.findByNombre(nuevoEstado)
                .orElseThrow(() -> new RuntimeException("Estado no encontrado"));

        queja.setEstado(estado);
        Queja quejaActualizada = quejaRepository.save(queja);
        return convertirADTO(quejaActualizada);
    }

    public long contarQuejasPorEstado(String estadoNombre) {
        return quejaRepository.countByEstadoNombre(estadoNombre);
    }

    private QuejaDTO convertirADTO(Queja queja) {
        QuejaDTO dto = new QuejaDTO();
        dto.setId(queja.getId());
        dto.setDescripcion(queja.getDescripcion());
        dto.setFechaCreacion(queja.getFechaCreacion());
        dto.setUsuarioId(queja.getUsuario().getId());
        dto.setUsuarioNombre(queja.getUsuario().getNombre());
        dto.setEstadoId(queja.getEstado().getId());
        dto.setEstadoNombre(queja.getEstado().getNombre());
        dto.setImagenUrl(queja.getImagenUrl());
        
        // Contar reacciones
        dto.setTotalLikes(reaccionRepository.countByQuejaIdAndTipoReaccionId(queja.getId(), 1L));
        dto.setTotalReacciones(reaccionRepository.findByQuejaId(queja.getId()).size());
        
        return dto;
    }
}
