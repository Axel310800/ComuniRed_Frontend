package com.comunired.application.service;

import com.comunired.domain.model.Usuario;
import com.comunired.domain.repository.UsuarioRepository;
import com.comunired.infrastructure.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UsuarioRepository usuarioRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtUtil jwtUtil;

    @Autowired
    public AuthService(UsuarioRepository usuarioRepository, 
                      PasswordEncoder passwordEncoder, 
                      JwtUtil jwtUtil) {
        this.usuarioRepository = usuarioRepository;
        this.passwordEncoder = passwordEncoder;
        this.jwtUtil = jwtUtil;
    }

    public AuthPayload login(String email, String password) {
        Usuario usuario = usuarioRepository.findByEmail(email)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        if (!passwordEncoder.matches(password, usuario.getPassword())) {
            throw new RuntimeException("Credenciales inválidas");
        }

        String token = jwtUtil.generateToken(usuario.getEmail(), usuario.getRol().getNombre());
        
        return new AuthPayload(token, usuario);
    }

    public static class AuthPayload {
        private final String token;
        private final Usuario usuario;

        public AuthPayload(String token, Usuario usuario) {
            this.token = token;
            this.usuario = usuario;
        }

        public String getToken() { return token; }
        public Usuario getUsuario() { return usuario; }
    }
}
