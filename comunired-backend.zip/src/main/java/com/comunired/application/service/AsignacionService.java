package com.comunired.application.service;

import com.comunired.domain.model.*;
import com.comunired.domain.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@Transactional
public class AsignacionService {

    private final AsignacionRepository asignacionRepository;
    private final QuejaRepository quejaRepository;
    private final UsuarioRepository usuarioRepository;
    private final EstadoQuejaRepository estadoQuejaRepository;

    @Autowired
    public AsignacionService(AsignacionRepository asignacionRepository,
                           QuejaRepository quejaRepository,
                           UsuarioRepository usuarioRepository,
                           EstadoQuejaRepository estadoQuejaRepository) {
        this.asignacionRepository = asignacionRepository;
        this.quejaRepository = quejaRepository;
        this.usuarioRepository = usuarioRepository;
        this.estadoQuejaRepository = estadoQuejaRepository;
    }

    public Asignacion asignarQuejaASoporte(Long quejaId, Long soporteId) {
        Queja queja = quejaRepository.findById(quejaId)
                .orElseThrow(() -> new RuntimeException("Queja no encontrada"));

        Usuario soporte = usuarioRepository.findById(soporteId)
                .orElseThrow(() -> new RuntimeException("Usuario de soporte no encontrado"));

        if (!soporte.esSoporte()) {
            throw new RuntimeException("El usuario no tiene rol de soporte");
        }

        if (!queja.puedeSerAsignada()) {
            throw new RuntimeException("La queja no puede ser asignada en su estado actual");
        }

        // Cambiar estado de la queja a EN_PROGRESO
        EstadoQueja estadoEnProgreso = estadoQuejaRepository.findByNombre("EN_PROGRESO")
                .orElseThrow(() -> new RuntimeException("Estado EN_PROGRESO no encontrado"));
        
        queja.marcarComoEnProgreso(estadoEnProgreso);
        quejaRepository.save(queja);

        // Crear asignación
        Asignacion asignacion = new Asignacion();
        asignacion.setQueja(queja);
        asignacion.setSoporte(soporte);
        asignacion.setFechaAsignacion(LocalDateTime.now());
        asignacion.setAtendida(false);

        return asignacionRepository.save(asignacion);
    }

    public List<Asignacion> obtenerAsignacionesPorSoporte(Long soporteId) {
        return asignacionRepository.findBySoporteId(soporteId);
    }

    public Asignacion marcarComoAtendida(Long asignacionId) {
        Asignacion asignacion = asignacionRepository.findById(asignacionId)
                .orElseThrow(() -> new RuntimeException("Asignación no encontrada"));

        if (!asignacion.puedeSerAtendida()) {
            throw new RuntimeException("La asignación no puede ser marcada como atendida");
        }

        asignacion.marcarComoAtendida();

        // Marcar queja como resuelta
        EstadoQueja estadoResuelto = estadoQuejaRepository.findByNombre("RESUELTO")
                .orElseThrow(() -> new RuntimeException("Estado RESUELTO no encontrado"));
        
        asignacion.getQueja().marcarComoResuelta(estadoResuelto);
        quejaRepository.save(asignacion.getQueja());

        return asignacionRepository.save(asignacion);
    }
}
