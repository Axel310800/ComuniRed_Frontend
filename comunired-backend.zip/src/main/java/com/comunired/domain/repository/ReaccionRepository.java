package com.comunired.domain.repository;

import com.comunired.domain.model.Reaccion;
import java.util.List;
import java.util.Optional;

public interface ReaccionRepository {
    Optional<Reaccion> findById(Long id);
    List<Reaccion> findByQuejaId(Long quejaId);
    Optional<Reaccion> findByUsuarioIdAndQuejaIdAndTipoReaccionId(Long usuarioId, Long quejaId, Long tipoReaccionId);
    long countByQuejaIdAndTipoReaccionId(Long quejaId, Long tipoReaccionId);
    Reaccion save(Reaccion reaccion);
    void deleteById(Long id);
}
