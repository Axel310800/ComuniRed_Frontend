package com.comunired.domain.repository;

import com.comunired.domain.model.EstadoQueja;
import java.util.List;
import java.util.Optional;

public interface EstadoQuejaRepository {
    Optional<EstadoQueja> findById(Long id);
    Optional<EstadoQueja> findByNombre(String nombre);
    List<EstadoQueja> findAll();
    EstadoQueja save(EstadoQueja estadoQueja);
}
