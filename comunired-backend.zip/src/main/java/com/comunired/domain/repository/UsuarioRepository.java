package com.comunired.domain.repository;

import com.comunired.domain.model.Usuario;
import java.util.List;
import java.util.Optional;

public interface UsuarioRepository {
    Optional<Usuario> findById(Long id);
    Optional<Usuario> findByEmail(String email);
    List<Usuario> findByRolNombre(String rolNombre);
    Usuario save(Usuario usuario);
    void deleteById(Long id);
    List<Usuario> findAll();
}
