package com.comunired.domain.repository;

import com.comunired.domain.model.Queja;
import java.util.List;
import java.util.Optional;

public interface QuejaRepository {
    Optional<Queja> findById(Long id);
    List<Queja> findAll();
    List<Queja> findByUsuarioId(Long usuarioId);
    List<Queja> findByEstadoNombre(String estadoNombre);
    Queja save(Queja queja);
    void deleteById(Long id);
    long countByEstadoNombre(String estadoNombre);
}
