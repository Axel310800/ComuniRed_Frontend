package com.comunired.domain.repository;

import com.comunired.domain.model.Asignacion;
import java.util.List;
import java.util.Optional;

public interface AsignacionRepository {
    Optional<Asignacion> findById(Long id);
    List<Asignacion> findBySoporteId(Long soporteId);
    List<Asignacion> findByQuejaId(Long quejaId);
    Optional<Asignacion> findByQuejaIdAndSoporteId(Long quejaId, Long soporteId);
    Asignacion save(Asignacion asignacion);
    void deleteById(Long id);
}
