package com.comunired.domain.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Queja {
    private Long id;
    private String descripcion;
    private LocalDateTime fechaCreacion;
    private Usuario usuario;
    private EstadoQueja estado;
    private String imagenUrl;

    public Queja() {}

    public Queja(Long id, String descripcion, LocalDateTime fechaCreacion, 
                 Usuario usuario, EstadoQueja estado, String imagenUrl) {
        this.id = id;
        this.descripcion = descripcion;
        this.fechaCreacion = fechaCreacion;
        this.usuario = usuario;
        this.estado = estado;
        this.imagenUrl = imagenUrl;
    }

    // Business methods
    public boolean puedeSerAsignada() {
        return estado != null && (estado.esPendiente() || estado.esEnProgreso());
    }

    public boolean puedeSerResuelta() {
        return estado != null && estado.esEnProgreso();
    }

    public void marcarComoEnProgreso(EstadoQueja estadoEnProgreso) {
        if (estado.esPendiente()) {
            this.estado = estadoEnProgreso;
        }
    }

    public void marcarComoResuelta(EstadoQueja estadoResuelto) {
        if (estado.esEnProgreso()) {
            this.estado = estadoResuelto;
        }
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public LocalDateTime getFechaCreacion() { return fechaCreacion; }
    public void setFechaCreacion(LocalDateTime fechaCreacion) { this.fechaCreacion = fechaCreacion; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public EstadoQueja getEstado() { return estado; }
    public void setEstado(EstadoQueja estado) { this.estado = estado; }

    public String getImagenUrl() { return imagenUrl; }
    public void setImagenUrl(String imagenUrl) { this.imagenUrl = imagenUrl; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Queja queja = (Queja) o;
        return Objects.equals(id, queja.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
