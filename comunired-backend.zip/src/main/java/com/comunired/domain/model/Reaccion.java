package com.comunired.domain.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Reaccion {
    private Long id;
    private Usuario usuario;
    private Queja queja;
    private TipoReaccion tipoReaccion;
    private LocalDateTime fecha;

    public Reaccion() {}

    public Reaccion(Long id, Usuario usuario, Queja queja, 
                   TipoReaccion tipoReaccion, LocalDateTime fecha) {
        this.id = id;
        this.usuario = usuario;
        this.queja = queja;
        this.tipoReaccion = tipoReaccion;
        this.fecha = fecha;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Usuario getUsuario() { return usuario; }
    public void setUsuario(Usuario usuario) { this.usuario = usuario; }

    public Queja getQueja() { return queja; }
    public void setQueja(Queja queja) { this.queja = queja; }

    public TipoReaccion getTipoReaccion() { return tipoReaccion; }
    public void setTipoReaccion(TipoReaccion tipoReaccion) { this.tipoReaccion = tipoReaccion; }

    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Reaccion reaccion = (Reaccion) o;
        return Objects.equals(id, reaccion.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
