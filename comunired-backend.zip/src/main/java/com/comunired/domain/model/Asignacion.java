package com.comunired.domain.model;

import java.time.LocalDateTime;
import java.util.Objects;

public class Asignacion {
    private Long id;
    private Queja queja;
    private Usuario soporte;
    private LocalDateTime fechaAsignacion;
    private boolean atendida;

    public Asignacion() {}

    public Asignacion(Long id, Queja queja, Usuario soporte, 
                     LocalDateTime fechaAsignacion, boolean atendida) {
        this.id = id;
        this.queja = queja;
        this.soporte = soporte;
        this.fechaAsignacion = fechaAsignacion;
        this.atendida = atendida;
    }

    // Business methods
    public void marcarComoAtendida() {
        this.atendida = true;
    }

    public boolean puedeSerAtendida() {
        return !atendida && queja.puedeSerResuelta();
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Queja getQueja() { return queja; }
    public void setQueja(Queja queja) { this.queja = queja; }

    public Usuario getSoporte() { return soporte; }
    public void setSoporte(Usuario soporte) { this.soporte = soporte; }

    public LocalDateTime getFechaAsignacion() { return fechaAsignacion; }
    public void setFechaAsignacion(LocalDateTime fechaAsignacion) { this.fechaAsignacion = fechaAsignacion; }

    public boolean isAtendida() { return atendida; }
    public void setAtendida(boolean atendida) { this.atendida = atendida; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Asignacion that = (Asignacion) o;
        return Objects.equals(id, that.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
