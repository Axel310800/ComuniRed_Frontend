-- Insertar roles básicos
INSERT INTO rol (nombre, descripcion) VALUES 
('ADMIN', 'Administrador del sistema'),
('SOPORTE', 'Personal de soporte técnico'),
('USUARIO', 'Usuario regular del sistema');

-- Insertar estados de queja
INSERT INTO estado_queja (nombre, descripcion) VALUES 
('PENDIENTE', 'Queja recién creada, pendiente de revisión'),
('EN_PROGRESO', 'Queja asignada y en proceso de resolución'),
('RESUELTO', 'Queja resuelta satisfactoriamente');

-- Insertar tipos de reacción
INSERT INTO tipo_reaccion (nombre, icono) VALUES 
('ME_GUSTA', '👍'),
('UTIL', '💡'),
('IMPORTANTE', '⚠️');

-- Insertar usuarios de ejemplo (password: "password123" encriptado con BCrypt)
INSERT INTO usuario (nombre, email, password, rol_id) VALUES 
('Administrador', 'admin@comunired.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 1),
('Soporte Técnico', 'soporte@comunired.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 2),
('Juan Pérez', 'juan@email.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 3),
('María García', 'maria@email.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2uheWG/igi.', 3);

-- Insertar quejas de ejemplo
INSERT INTO queja (descripcion, fecha_creacion, usuario_id, estado_id, imagen_url) VALUES 
('Problema con el alumbrado público en la calle principal', NOW(), 3, 1, 'https://example.com/imagen1.jpg'),
('Bache grande en la avenida central que causa daños a los vehículos', NOW(), 4, 1, 'https://example.com/imagen2.jpg'),
('Ruido excesivo por construcción durante horas no permitidas', NOW(), 3, 2, NULL);

-- Insertar asignación de ejemplo
INSERT INTO asignacion (queja_id, soporte_id, fecha_asignacion, atendida) VALUES 
(3, 2, NOW(), FALSE);
